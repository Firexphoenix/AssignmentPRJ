document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("search-input");
    const movies = document.querySelectorAll(".movie-card");

    // Hàm debounce giúp tối ưu hiệu suất
    function debounce(func, delay) {
        let timeout;
        return (...args) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => func(...args), delay);
        };
    }

    function filterMovies() {
        const query = searchInput.value.trim().toLowerCase();
        movies.forEach(movie => {
            const title = movie.getAttribute("data-title").toLowerCase();
            movie.classList.toggle("hidden", !title.includes(query));
        });
    }

    searchInput.addEventListener("input", debounce(filterMovies, 300));
});

