package Controller;

import accountDao.AccountDao;
import Model.Account;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private AccountDao accountDao;

    @Override
    public void init() {
        accountDao = new AccountDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("userEmail") != null) {
            redirectToDashboard(session, response);
            return;
        }
        request.getRequestDispatcher("login/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Email và mật khẩu không được để trống!");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        Account account = accountDao.getAccountByEmail(email);

        if (account == null || !password.equals(account.getPassword())) {
            request.setAttribute("errorMessage", "Email hoặc mật khẩu không đúng!");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        createSession(request, account.getEmail(), account.getRole());
        redirectToDashboard(request.getSession(), response);
    }

    // Tạo session
    private void createSession(HttpServletRequest request, String email, String role) {
        HttpSession session = request.getSession();
        session.setAttribute("userEmail", email);
        session.setAttribute("role", role);
    }

    // Điều hướng dựa theo role
    private void redirectToDashboard(HttpSession session, HttpServletResponse response) throws IOException {
        String role = (String) session.getAttribute("role");

        if (role == null) {
            response.sendRedirect("login/login.jsp");
            return;
        }

        switch (role) {
            case "Customer":
                response.sendRedirect("customer/customerProfile.jsp");
                break;
            case "Manager":
                response.sendRedirect("manager/managerDashboard.jsp");
                break;
            case "Employee":
                response.sendRedirect("employee/empDashboard.jsp");
                break;
            default:
                response.sendRedirect("login/login.jsp");
        }
    }
}
