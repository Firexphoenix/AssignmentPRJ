//package Controller;
//
//import com.google.api.client.auth.oauth2.AuthorizationCodeFlow;
//import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
//import com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest;
//import com.google.api.client.auth.oauth2.Credential;
//import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
//import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
//import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
//import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
//import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
//import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
//import com.google.api.client.http.javanet.NetHttpTransport;
//import com.google.api.client.json.JsonFactory;
//import com.google.api.client.json.jackson2.JacksonFactory;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.util.Collections;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.annotation.WebServlet;
//import jakarta.servlet.http.HttpServlet;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpSession;
//
//@WebServlet(name = "GoogleLoginServlet", urlPatterns = {"/loginGoogle"})
//public class GoogleLoginServlet extends HttpServlet {
//    
//    private static final String CLIENT_ID = "906755091792-sg2ech4edan4o0i4929ng2tkaic6lpdp.apps.googleusercontent.com";  
//    private static final String CLIENT_SECRET = "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";
//    private static final String REDIRECT_URI = "http://localhost:8080/CinemaTicketBooking/loginGoogle";
//    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
//    
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
//        String code = request.getParameter("code");
//        
//        if (code == null) {
//            response.sendRedirect(getGoogleAuthUrl());
//            return;
//        }
//        
//        Credential credential = exchangeCodeForToken(code);
//        if (credential == null) {
//            response.sendRedirect("login.jsp?error=google_auth_failed");
//            return;
//        }
//        
//        GoogleIdToken idToken = verifyIdToken(credential.getAccessToken());
//        if (idToken == null) {
//            response.sendRedirect("login.jsp?error=invalid_token");
//            return;
//        }
//        
//        Payload payload = idToken.getPayload();
//        String email = payload.getEmail();
//        String name = (String) payload.get("name");
//        
//        HttpSession session = request.getSession();
//        session.setAttribute("userEmail", email);
//        session.setAttribute("userName", name);
//        session.setAttribute("role", "Customer"); 
//        
//        response.sendRedirect("index.html");
//    }
//    
//    private String getGoogleAuthUrl() {
//        AuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
//                new NetHttpTransport(),
//                JSON_FACTORY,
//                CLIENT_ID,
//                CLIENT_SECRET,
//                Collections.singletonList("email"))
//                .build();
//
//        AuthorizationCodeRequestUrl authorizationUrl = flow.newAuthorizationUrl().setRedirectUri(REDIRECT_URI);
//        return authorizationUrl.build();
//    }
//    
//    private Credential exchangeCodeForToken(String code) throws IOException {
//        return new GoogleAuthorizationCodeTokenRequest(
//                new NetHttpTransport(),
//                JSON_FACTORY,
//                CLIENT_ID,
//                CLIENT_SECRET,
//                code,
//                REDIRECT_URI)
//                .execute()
//                .toCredential();
//    }
//
//    private GoogleIdToken verifyIdToken(String accessToken) throws IOException {
//        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
//                new NetHttpTransport(),
//                JSON_FACTORY)
//                .setAudience(Collections.singletonList(CLIENT_ID))
//                .build();
//
//        return verifier.verify(accessToken);
//    }
//}
