package employeeDao;

import Model.Employee;
import java.sql.SQLException;
import java.util.List;

public interface IEmployeeDao {
    
    public void insertEmployee(Employee emp) throws SQLException;

    public Employee selectEmployee(String empID);

    public List<Employee> selectAllEmployees();

    public boolean deleteEmployee(String empID) throws SQLException;

    public boolean updateEmployee(Employee emp) throws SQLException;
    
}
