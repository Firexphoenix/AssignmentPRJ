package employeeDao;

import Model.Employee;
import dao.DBconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDao implements IEmployeeDao {

    private static final String INSERT_EMPLOYEE = "INSERT INTO Employee (EmpID, EmpName, Salary, PhoneNumber, Email, Gender, Birthday, HireDate, Address, CinemaID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SELECT_EMPLOYEE_BY_ID = "SELECT * FROM Employee WHERE EmpID = ?";
    private static final String UPDATE_EMPLOYEE = "UPDATE Employee SET EmpName = ?, Salary = ?, PhoneNumber = ?, Email = ?, Gender = ?, Birthday = ?, HireDate = ?, Address = ?, CinemaID = ? WHERE EmpID = ?";
    private static final String SELECT_ALL_EMPLOYEES = "SELECT * FROM Employee";
    private static final String DELETE_EMPLOYEE_SQL = "DELETE FROM Employee WHERE EmpID = ?";
    private static final String SELECT_EMPLOYEE_BY_EMAIL = "SELECT * FROM Employee WHERE Email = ?";

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

    @Override
    public void insertEmployee(Employee emp) throws SQLException {
        try (Connection conn = DBconnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(INSERT_EMPLOYEE);
                ps.setString(1, emp.getEmpID());
                ps.setString(2, emp.getEmpName());
                ps.setDouble(3, emp.getSalary());
                ps.setString(4, emp.getPhoneNumber());
                ps.setString(5, emp.getEmail());
                ps.setString(6, emp.getGender());
                ps.setDate(7, emp.getBirthday());
                ps.setDate(8, emp.getHireDate());
                ps.setString(9, emp.getAddress());
                ps.setString(10, emp.getCinemaID());

                ps.executeUpdate();
            }
        }
    }

    @Override
    public Employee selectEmployee(String empID) {
        Employee emp = null;
        try (Connection conn = DBconnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(SELECT_EMPLOYEE_BY_ID);
                ps.setString(1, empID);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    emp = new Employee(
                            rs.getString("EmpID"),
                            rs.getString("EmpName"),
                            rs.getDouble("Salary"),
                            rs.getString("PhoneNumber"),
                            rs.getString("Email"),
                            rs.getString("Gender"),
                            rs.getDate("Birthday"),
                            rs.getDate("HireDate"),
                            rs.getString("Address"),
                            rs.getString("CinemaID")
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return emp;
    }

    @Override
    public List<Employee> selectAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        try (Connection conn = DBconnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(SELECT_ALL_EMPLOYEES);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    employees.add(new Employee(
                            rs.getString("EmpID"),
                            rs.getString("EmpName"),
                            rs.getDouble("Salary"),
                            rs.getString("PhoneNumber"),
                            rs.getString("Email"),
                            rs.getString("Gender"),
                            rs.getDate("Birthday"),
                            rs.getDate("HireDate"),
                            rs.getString("Address"),
                            rs.getString("CinemaID")
                    ));
                }
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return employees;
    }

    @Override
    public boolean deleteEmployee(String empID) throws SQLException {
        boolean rowDeleted = false;
        try (Connection conn = DBconnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(DELETE_EMPLOYEE_SQL);
                ps.setString(1, empID);
                rowDeleted = ps.executeUpdate() > 0;
            }
        }
        return rowDeleted;
    }

    @Override
    public boolean updateEmployee(Employee emp) throws SQLException {
        boolean rowUpdated = false;
        try (Connection conn = DBconnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(UPDATE_EMPLOYEE);
                ps.setString(1, emp.getEmpName());
                ps.setDouble(2, emp.getSalary());
                ps.setString(3, emp.getPhoneNumber());
                ps.setString(4, emp.getEmail());
                ps.setString(5, emp.getGender());
                ps.setDate(6, emp.getBirthday());
                ps.setDate(7, emp.getHireDate());
                ps.setString(8, emp.getAddress());
                ps.setString(9, emp.getCinemaID());
                ps.setString(10, emp.getEmpID());

                rowUpdated = ps.executeUpdate() > 0;
            }
        }
        return rowUpdated;
    }
    
    public Employee getEmployeeByEmail(String email) {
    Employee employee = null;
    String query = "SELECT EmpID, EmpName, Salary, PhoneNumber, Email, Gender, Birthday, HireDate, Address, CinemaID FROM Employee WHERE Email = ?";

    try (Connection conn = DBconnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)) {
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            employee = new Employee(
                rs.getString("EmpID"),
                rs.getString("EmpName"),
                rs.getDouble("Salary"),
                rs.getString("PhoneNumber"),
                rs.getString("Email"),
                rs.getString("Gender"),
                rs.getDate("Birthday"),
                rs.getDate("HireDate"),
                rs.getString("Address"),
                rs.getString("CinemaID")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return employee;
}

}
