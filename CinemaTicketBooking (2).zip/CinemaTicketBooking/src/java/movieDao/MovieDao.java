package movieDao;

///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package Service;
//
//import Model.Movie;
//import dao.DBconnection;
//import java.sql.SQLException;
//import java.util.List;
//
///**
// *
// * @author Le Vu Minh Hoang
// */
//public class MovieDao implements IMovieDao{
//    private static final String INSERT_Movie = "INSERT INTO Movie (username, email, country, role, status, password) VALUES (?, ?, ?, ?, ?, ?)";
//    private static final String SELECT_USER_BY_ID = "SELECT * FROM Users WHERE id = ?";
//    private static final String UPDATE_USER = "UPDATE Users SET username = ?, email = ?, country = ?, role = ?, status = ?, password = ? WHERE id = ?";
//    private static final String SELECT_ALL_USERS = "select * from users";
//    private static final String DELETE_USER_SQL = "DELETE FROM Users WHERE id = ?";
//
//    private void printSQLException(SQLException ex) {
//        for (Throwable e : ex) {
//            if (e instanceof SQLException) {
//                e.printStackTrace(System.err);
//                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
//                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
//                System.err.println("Message: " + e.getMessage());
//                Throwable t = ex.getCause();
//                while (t != null) {
//                    System.out.println("Cause: " + t);
//                    t = t.getCause();
//                }
//            }
//        }
//    }
//
//    @Override
//    public void insertMovie(Movie user) throws SQLException {
//        try (Connection conn = DBconnection.getConnection()) {
//            if (conn != null) {
//                PreparedStatement ps = conn.prepareStatement(INSERT_USER);
//                ps.setString(1, user.getUsername());
//                ps.setString(2, user.getEmail());
//                ps.setString(3, user.getCountry());
//                ps.setString(4, user.getRole());
//                ps.setBoolean(5, user.isStatus());
//                ps.setString(6, user.getPassword());
//                int rowsInserted = ps.executeUpdate();
//                if (rowsInserted > 0) {
//                    System.out.println("A new user was inserted successfully!");
//                }
//            }
//        }
//    }
//
//    @Override
//    public User selectUser(int id) {
//        User user = null;
//        try (Connection conn = DBconnection.getConnection()) {
//            if (conn != null) {
//                PreparedStatement ps = conn.prepareStatement(SELECT_USER_BY_ID);
//                ps.setInt(1, id);
//                ResultSet rs = ps.executeQuery();
//                if (rs.next()) {
//                    user = new User(
//                            rs.getInt("id"),
//                            rs.getString("username"),
//                            rs.getString("email"),
//                            rs.getString("country"),
//                            rs.getString("role"),
//                            rs.getBoolean("status"),
//                            rs.getString("password")
//                    );
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return user;
//    }
//
//    @Override
//    public List<User> selectAllUsers() {
//        List<User> users = new ArrayList<>();
//        try (Connection conn = DBconnection.getConnection()) {
//            if (conn != null) {
//                PreparedStatement preparedStatement = conn.prepareStatement(SELECT_ALL_USERS);
//                ResultSet rs = preparedStatement.executeQuery();
//                while (rs.next()) {
//                    int id = rs.getInt("id");
//                    String name = rs.getString("username");
//                    String email = rs.getString("email");
//                    String country = rs.getString("country");
//                    String role = rs.getString("role");
//                    boolean status = rs.getBoolean("status");
//                    String password = rs.getString("password");
//                    users.add(new User(id, name, email, country, role, status, password));
//                }
//            }
//        } catch (SQLException e) {
//            printSQLException(e);
//        }
//        return users;
//    }
//
//    @Override
//    public boolean deleteUser(int id) throws SQLException {
//        boolean rowDeleted = false;
//        try (Connection conn = DBconnection.getConnection()) {
//            if (conn != null) {
//                PreparedStatement ps = conn.prepareStatement(DELETE_USER_SQL);
//                ps.setInt(1, id);
//                rowDeleted = ps.executeUpdate() > 0;
//            }
//        }
//        return rowDeleted;
//    }
//
//    @Override
//    public boolean updateUser(User user) throws SQLException {
//        boolean rowUpdated = false;
//        try (Connection conn = DBconnection.getConnection()) {
//            if (conn != null) {
//                PreparedStatement ps = conn.prepareStatement(UPDATE_USER);
//
//                ps.setString(1, user.getUsername());
//                ps.setString(2, user.getEmail());
//                ps.setString(3, user.getCountry());
//                ps.setString(4, user.getRole());
//                ps.setBoolean(5, user.isStatus());
//                ps.setString(6, user.getPassword());
//                ps.setInt(7, user.getId());
//                rowUpdated = ps.executeUpdate() > 0;
//            }
//        }
//        return rowUpdated;
//    }
//
//    @Override
//    public boolean checkLogin(String username, String password, String role) {
//        try (Connection con = DBconnection.getConnection()) {
//            PreparedStatement ptm = con.prepareStatement(LOGIN);
//            ptm.setString(1, username);
//            ptm.setString(2, password);
//            ptm.setString(3, role);
//            ResultSet rs = ptm.executeQuery();
//            if (rs.next()) {
//                return true;
//            } else {
//                System.out.println("Login failed: Invalid username or password.");
//                return false;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }
//}
