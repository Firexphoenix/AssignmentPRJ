package customerDao;

import Model.Customer;
import dao.DBconnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDao {
    private static final String INSERT_CUSTOMER = "INSERT INTO Customer (CustomerID, CustomerName, Email, PhoneNumber, Birthday, Gender) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_CUSTOMER_BY_ID = "SELECT * FROM Customer WHERE CustomerID = ?";
    private static final String SELECT_CUSTOMER_BY_EMAIL = "SELECT * FROM Customer WHERE Email = ?";
    private static final String UPDATE_CUSTOMER = "UPDATE Customer SET CustomerName = ?, PhoneNumber = ?, Birthday = ?, Gender = ? WHERE CustomerID = ?";
    private static final String DELETE_CUSTOMER = "DELETE FROM Customer WHERE CustomerID = ?";
    private static final String SELECT_ALL_CUSTOMERS = "SELECT * FROM Customer";
    private static final String CHECK_LOGIN = "SELECT * FROM Account WHERE Email = ? AND Password = ? AND Role = 'Customer'";

    public void insertCustomer(Customer customer) throws SQLException {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_CUSTOMER)) {
            ps.setString(1, customer.getCustomerID());
            ps.setString(2, customer.getCustomerName());
            ps.setString(3, customer.getEmail());
            ps.setString(4, customer.getPhoneNumber());
            ps.setDate(5, customer.getBirthday() != null ? new Date(customer.getBirthday().getTime()) : null);
            ps.setString(6, customer.getGender());
            ps.executeUpdate();
        }
    }

    public Customer getCustomerById(String customerID) {
        Customer customer = null;
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_CUSTOMER_BY_ID)) {
            ps.setString(1, customerID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                customer = new Customer(
                        rs.getString("CustomerID"),
                        rs.getString("CustomerName"),
                        rs.getString("Email"),
                        rs.getString("PhoneNumber"),
                        rs.getDate("Birthday"),
                        rs.getString("Gender")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }

    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_ALL_CUSTOMERS);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                customers.add(new Customer(
                        rs.getString("CustomerID"),
                        rs.getString("CustomerName"),
                        rs.getString("Email"),
                        rs.getString("PhoneNumber"),
                        rs.getDate("Birthday"),
                        rs.getString("Gender")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }

    public boolean updateCustomer(Customer customer) throws SQLException {
        boolean rowUpdated;
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_CUSTOMER)) {
            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getPhoneNumber());
            ps.setDate(3, customer.getBirthday() != null ? new Date(customer.getBirthday().getTime()) : null);
            ps.setString(4, customer.getGender());
            ps.setString(5, customer.getCustomerID());
            rowUpdated = ps.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public boolean deleteCustomer(String customerID) throws SQLException {
        boolean rowDeleted;
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_CUSTOMER)) {
            ps.setString(1, customerID);
            rowDeleted = ps.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    // Kiểm tra đăng nhập từ bảng Account, nếu đúng thì lấy thông tin từ bảng Customer
    public Customer loginCustomer(String email, String password) {
        Customer customer = null;
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(CHECK_LOGIN)) {
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Nếu login đúng, lấy thông tin Customer từ bảng Customer
                customer = getCustomerByEmail(email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }

    // Lấy thông tin Customer từ bảng Customer bằng email
    public Customer getCustomerByEmail(String email) {
        Customer customer = null;
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_CUSTOMER_BY_EMAIL)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                customer = new Customer(
                        rs.getString("CustomerID"),
                        rs.getString("CustomerName"),
                        rs.getString("Email"),
                        rs.getString("PhoneNumber"),
                        rs.getDate("Birthday"),
                        rs.getString("Gender")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }
}

