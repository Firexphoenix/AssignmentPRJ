package customerDao;

import Model.Customer;
import java.util.List;
import java.sql.SQLException;


public interface ICustomerDao {
    
    public void insertEmployee(Customer customer) throws SQLException;

    public Customer selectCustomer(String empID);

    public List<Customer> selectAllCustomers();

    public boolean deleteCustomer(String customerID) throws SQLException;

    public boolean updateCustomer(Customer customer) throws SQLException;
    
}
